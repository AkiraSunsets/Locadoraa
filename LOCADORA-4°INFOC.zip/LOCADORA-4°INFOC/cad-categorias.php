<h2>Cadastro de nova categoria</h2>

<form action="index.php?menu=inserir-categorias" method="post">
    <div>
        <label for="nomeCategoria">Nome da Categoria</label>
        <input type="text" name="nomeCategoria" id="nomeCategoria">
    </div>
  
    <div>
         <input type="submit" value="Salvar">   
    </div>
</form>